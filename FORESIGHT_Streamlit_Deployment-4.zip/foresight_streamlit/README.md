# FORESIGHT — Streamlit Deployment

Ready-to-deploy planning dashboard for Project FORESIGHT — Demand & Inventory Intelligence.

## Included
- `app.py` — Streamlit dashboard
- `requirements.txt` — Python dependencies
- `data/` — supplied four Excel extracts
- `notebooks/` — five project notebooks

## Dashboard
The app provides SKU/category filters, demand forecast views, stockout/overstock risk, reorder and markdown actions, sales-at-risk, locked-capital estimates, and CSV downloads.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Community Cloud
1. Create a GitHub repository and upload this folder.
2. Open Streamlit Community Cloud.
3. Create a new app and select the repository/branch.
4. Set the main file to `app.py`.
5. Deploy.

## Important project note
The deployed dashboard uses a transparent recent-28-day demand calculation so it can run directly from the supplied extracts. For the final FORESIGHT submission, connect the dashboard to the validated forecast from `04_Forecast.ipynb` and report WAPE against the seasonal-naive baseline using rolling-origin backtesting.

## Data files
The app expects:
- `data/sales_daily.xlsx`
- `data/sku_master.xlsx`
- `data/inventory_snapshots.xlsx`
- `data/calendar.xlsx`

Do not publish confidential raw data unless your project rules permit it.
