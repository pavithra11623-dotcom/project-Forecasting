import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path
import plotly.express as px

st.set_page_config(page_title='FORESIGHT — Demand & Inventory Intelligence', page_icon='📦', layout='wide')
BASE = Path(__file__).parent
DATA = BASE / 'data'

@st.cache_data
def load_data():
    paths = {k: DATA / f for k, f in {
        'sales':'sales_daily.xlsx','sku':'sku_master.xlsx','inventory':'inventory_snapshots.xlsx','calendar':'calendar.xlsx'}.items()}
    missing = [p.name for p in paths.values() if not p.exists()]
    if missing:
        raise FileNotFoundError('Missing data files: ' + ', '.join(missing))
    sales, sku, inventory, calendar = [pd.read_excel(paths[k]) for k in ['sales','sku','inventory','calendar']]
    for df in [sales, sku, inventory, calendar]: df.columns = [str(c).strip().lower() for c in df.columns]
    for df in [sales, inventory, calendar]:
        if 'date' in df: df['date'] = pd.to_datetime(df['date'], errors='coerce')
    if 'launch_date' in sku: sku['launch_date'] = pd.to_datetime(sku['launch_date'], errors='coerce')
    for df in [sales, sku, inventory]:
        if 'sku_id' in df: df['sku_id'] = df['sku_id'].astype(str)
    return sales, sku, inventory, calendar

def build_outputs(sales, sku, inventory):
    sales = sales.copy(); inv = inventory.sort_values('date').drop_duplicates('sku_id', keep='last').copy()
    sales['units_sold'] = pd.to_numeric(sales['units_sold'], errors='coerce').fillna(0)
    for c in ['on_hand_units','on_order_units','lead_time_days','reorder_point']:
        if c in inv: inv[c] = pd.to_numeric(inv[c], errors='coerce').fillna(0)
    latest = sales['date'].max(); recent = sales[sales['date'] >= latest - pd.Timedelta(days=27)]
    d = recent.groupby('sku_id', as_index=False)['units_sold'].sum().rename(columns={'units_sold':'recent_28d_units'})
    d['avg_daily_demand'] = d['recent_28d_units']/28; d['forecast_7d'] = d['avg_daily_demand']*7; d['forecast_28d'] = d['avg_daily_demand']*28
    out = inv.merge(d, on='sku_id', how='outer').merge(sku, on='sku_id', how='left', suffixes=('','_master'))
    for c in ['on_hand_units','on_order_units','lead_time_days','reorder_point','recent_28d_units','avg_daily_demand','forecast_7d','forecast_28d']:
        if c in out: out[c] = pd.to_numeric(out[c], errors='coerce').fillna(0)
    out['lead_time_demand'] = out['avg_daily_demand']*out['lead_time_days']; out['available_units'] = out['on_hand_units']+out['on_order_units']
    safety = np.maximum(out['forecast_7d']*.25, out['reorder_point']*.25)
    stockout = out['lead_time_demand'] + safety > out['available_units']
    ratio = np.where(out['forecast_28d']>0, out['on_hand_units']/out['forecast_28d'], np.inf)
    overstock = ratio >= 2
    out['risk_level'] = np.select([stockout & ~overstock, overstock & ~stockout, stockout & overstock], ['High stockout','High overstock','Watch / volatile'], default='Healthy')
    out['recommended_action'] = np.select([stockout & ~overstock, overstock & ~stockout, stockout & overstock], ['Reorder now','Markdown / clear','Watch / investigate'], default='No action')
    unit_cost = pd.to_numeric(out.get('unit_cost', 0), errors='coerce').fillna(0); price = pd.to_numeric(out.get('list_price',0), errors='coerce').fillna(0)
    out['sales_at_risk'] = np.maximum(out['lead_time_demand']+safety-out['available_units'],0)*np.where(unit_cost>0,unit_cost,price)
    out['locked_capital'] = np.maximum(out['on_hand_units']-out['forecast_28d'],0)*unit_cost
    return out, latest

try: sales, sku, inventory, calendar = load_data(); result, latest = build_outputs(sales, sku, inventory)
except Exception as e: st.error(str(e)); st.stop()

st.title('📦 FORESIGHT'); st.caption('Demand & Inventory Intelligence — NorthBay Living')
st.sidebar.header('Filters')
categories = sorted(result['category'].dropna().astype(str).unique()) if 'category' in result else []
sel_cat = st.sidebar.multiselect('Category', categories, default=categories)
sel_sku = st.sidebar.multiselect('SKU', sorted(result.sku_id.astype(str).unique()))
sel_risk = st.sidebar.multiselect('Risk level',['Healthy','High stockout','High overstock','Watch / volatile'],default=['Healthy','High stockout','High overstock','Watch / volatile'])
view = result.copy()
if categories: view = view[view.category.astype(str).isin(sel_cat)]
if sel_sku: view = view[view.sku_id.astype(str).isin(sel_sku)]
view = view[view.risk_level.isin(sel_risk)]

c1,c2,c3,c4=st.columns(4)
c1.metric('SKUs',f'{len(view):,}'); c2.metric('Reorder now',f'{(view.recommended_action=="Reorder now").sum():,}'); c3.metric('Markdown / clear',f'{(view.recommended_action=="Markdown / clear").sum():,}'); c4.metric('Sales at risk',f'₹{view.sales_at_risk.sum():,.0f}')
st.divider()
t1,t2,t3,t4=st.tabs(['📊 Overview','🔮 Forecast','🚨 Risk & Actions','📥 Data'])
with t1:
    st.subheader('Risk distribution'); rc=view.risk_level.value_counts().rename_axis('risk_level').reset_index(name='sku_count'); st.plotly_chart(px.bar(rc,x='risk_level',y='sku_count'),use_container_width=True)
    a,b=st.columns(2)
    with a:
        if 'category' in view:
            cat=view.groupby('category',as_index=False).forecast_28d.sum().sort_values('forecast_28d',ascending=False); st.plotly_chart(px.bar(cat,x='category',y='forecast_28d',title='Forecast demand — next 28 days'),use_container_width=True)
    with b: st.metric('Locked capital',f'₹{view.locked_capital.sum():,.0f}'); st.metric('28-day forecast',f'{view.forecast_28d.sum():,.0f} units')
with t2:
    st.subheader('SKU-level demand forecast'); st.caption(f'Latest sales date: {latest.date() if pd.notna(latest) else "N/A"}. Forecast uses recent 28-day demand as a transparent deployed baseline.')
    cols=[c for c in ['sku_id','category','subcategory','recent_28d_units','avg_daily_demand','forecast_7d','forecast_28d'] if c in view]; st.dataframe(view[cols].sort_values('forecast_28d',ascending=False),use_container_width=True,hide_index=True)
    chosen=st.selectbox('Select SKU for demand history',sorted(sales.sku_id.astype(str).unique())); hist=sales[sales.sku_id.astype(str)==chosen].groupby('date',as_index=False).units_sold.sum(); st.plotly_chart(px.line(hist,x='date',y='units_sold',title=f'Demand history — {chosen}'),use_container_width=True)
with t3:
    st.subheader('Prioritized decisions'); actions=st.multiselect('Actions',['Reorder now','Markdown / clear','Watch / investigate','No action'],default=['Reorder now','Markdown / clear','Watch / investigate']); x=view[view.recommended_action.isin(actions)]; cols=[c for c in ['sku_id','category','on_hand_units','on_order_units','lead_time_days','reorder_point','forecast_7d','forecast_28d','risk_level','recommended_action','sales_at_risk','locked_capital'] if c in x]; st.dataframe(x[cols].sort_values('sales_at_risk',ascending=False),use_container_width=True,hide_index=True); st.download_button('⬇️ Download prioritized actions CSV',x[cols].to_csv(index=False).encode(), 'foresight_prioritized_actions.csv','text/csv')
with t4:
    st.subheader('Source data summary'); st.write(f'Sales rows: **{len(sales):,}**'); st.write(f'SKU master rows: **{len(sku):,}**'); st.write(f'Inventory snapshots: **{len(inventory):,}**'); st.write(f'Calendar rows: **{len(calendar):,}**'); st.download_button('⬇️ Download forecast/risk table',result.to_csv(index=False).encode(),'foresight_forecast_risk.csv','text/csv')
st.divider(); st.caption('FORESIGHT planning dashboard. Replace the deployed baseline calculation with the validated notebook forecast before final submission.')
